package inventory.management.system;

import org.springframework.stereotype.Service;

import java.util.List;

public class Exercise5 {


    public List<Task> addTask(Task Task) {
        if (Task != null) {
            Task.tasks.add(Task);
            return Task.tasks;
        }
        return null;
    }

    public Task addTask(int TaskId) {

        return Task.tasks.stream().filter(e -> e.getTaskId() == TaskId).findAny().get();
    }

    public void traverse() {
        for (Task Task : Task.tasks) {
            System.out.println(Task + " ");

        }
    }

    public boolean deleteTask(Task Taskq) {
        List<Task> Tasks = Task.tasks;
        if (Tasks.isEmpty()) {
            return false;
        }
        return Tasks.remove(Taskq);
    }
}
