package inventory.management.system;

import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Exercise1And2 {

    public List<Product> addProduct(Product product) {
        List<Product> products = Product.products;
        if (products.isEmpty()) {
            products.add(product);
        }
        boolean isProductExist = products.stream().anyMatch(p -> p.getProductId() == product.getProductId());
        if (!isProductExist) {
            products.add(product);
        }
        return products;
    }

    public List<Product> updateProduct(Product product) {
        List<Product> products = Product.products;
        if (products.isEmpty()) {
            return null;
        }
        return products.stream().filter(p -> p.getProductId() == product.getProductId()).map(p1 -> p1 = product).collect(Collectors.toList());

    }

    public boolean deleteProduct(Product product) {
        List<Product> products = Product.products;
        if (products.isEmpty()) {
            return false;
        }
        return products.remove(product);
    }

    public Product binarySearchResult(Product product) {
        List<Product> products = Product.products;
        if (products.isEmpty()) {
            return null;
        }
        Collections.sort(products, new Comparator<Product>() {
            @Override
            public int compare(Product o1, Product o2) {
                if (o1.getProductId() > o2.getProductId()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });

        return binarySearch(products, product);
    }

    public Product binarySearch(List<Product> products, Product product) {
        int left = 0;
        int right = products.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Product midProduct = products.get(mid);

            if (midProduct.getProductId() == product.getProductId()) {
                return products.get(mid); // target found
            } else if (midProduct.getProductId() < product.getProductId()) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;


    }

    public Product linearSearchResult(Product product) {
        List<Product> products = Product.products;
        if (products.isEmpty()) {
            return null;
        }

        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProductId() == product.getProductId()) {
                return products.get(i);
            }
        }

        return null;
    }
}
