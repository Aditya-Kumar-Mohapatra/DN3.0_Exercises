package inventory.management.system;

import org.springframework.stereotype.Service;

import java.util.List;

public class Exercise4 {

    public List<Employee> addEmployee(Employee employee) {
        if (employee != null) {
            Employee.employeeList.add(employee);
            return Employee.employeeList;
        }
        return null;
    }

    public Employee addEmployee(int employeeId) {
        Employee employee = Employee.employeeList.stream().filter(e -> e.getEmployeeId() == employeeId).findAny().get();
        return employee;
    }

    public void traverse() {
        for (Employee employee : Employee.employeeList) {
            System.out.println(employee+ " ");

        }
    }

    public boolean deleteEmployee(Employee employee) {
        List<Employee> employees = Employee.employeeList;
        if (employees.isEmpty()) {
            return false;
        }
        return employees.remove(employee);
    }
}
