package inventory.management.system;

import org.springframework.stereotype.Service;

import java.util.List;

public class Exercise6 {
    public boolean linearSearch(String title) {
        List<Book> books = Book.books;
        for (Book k : books) {
            if (title.equalsIgnoreCase(k.getTitle())) {
                return true;
            }
        }
        return false;
    }

    public int binarrySearch(String title) {
        List<Book> books = Book.books;
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);
            int comparison = midBook.getTitle().compareTo(title);

            if (comparison == 0) {
                return mid;
            } else if (comparison < 0) {
                left = mid + 1; // Search in the right half
            } else {
                right = mid - 1; // Search in the left half
            }
        }

        return -1; // Target not found
    }
}
