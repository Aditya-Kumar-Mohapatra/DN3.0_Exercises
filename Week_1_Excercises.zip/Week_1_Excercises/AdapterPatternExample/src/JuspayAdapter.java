public class JuspayAdapter implements PaymentProcessor{
    private JuspayGateway juspayGateway;

    public JuspayAdapter(JuspayGateway juspayGateway) {
        this.juspayGateway = juspayGateway;
    }

    @Override
    public void processPayment() {
        System.out.print("Inside method");
    }
}
