public class Test {
    public static void main(String[] args) {
        JuspayGateway juspayGateway = new JuspayGateway();
        juspayGateway.makePayment(9.3);
    }
}
