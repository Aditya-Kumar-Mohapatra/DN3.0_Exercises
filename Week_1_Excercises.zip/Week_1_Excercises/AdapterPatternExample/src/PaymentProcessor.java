public interface PaymentProcessor {
    void processPayment();
}
