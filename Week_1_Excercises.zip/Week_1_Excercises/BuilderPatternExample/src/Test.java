public class Test {
    public static void main(String[] args){
        Computer computer = new Computer("12","22","500", new Computer.Builder());
        System.out.print(computer.getCPU());
    }
}
