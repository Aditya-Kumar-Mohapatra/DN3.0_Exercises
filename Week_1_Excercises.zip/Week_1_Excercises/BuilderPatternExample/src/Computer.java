public class Computer {
    private String CPU;
    private String RAM;
    private String storage;

    public static class Builder {
        public static Computer build(){
            return new Computer("12", "5", "500");
        }
    }

    public String getCPU() {
        return CPU;
    }

    public void setCPU(String CPU) {
        this.CPU = CPU;
    }

    public String getRAM() {
        return RAM;
    }

    public void setRAM(String RAM) {
        this.RAM = RAM;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public Computer(String CPU, String RAM, String storage) {
        this.CPU = CPU;
        this.RAM = RAM;
        this.storage = storage;
    }

    Computer(String CPU, String RAM, String storage, Builder builder) {
        this.CPU = CPU;
        this.RAM = RAM;
        this.storage = storage;
    }

}
