public class Test {
    public class Main {
        public static void main(String[] args) {
            StockMarket stockMarket = new StockMarket();

            Observer mobileApp = new MobileApp("MobileApp");
            Observer webApp = new WebApp("WebApp");

            stockMarket.register(mobileApp);
            stockMarket.register(webApp);

            System.out.println("Setting price to 100.00");
            stockMarket.setPrice(100.00);

            stockMarket.deregister(mobileApp);

            System.out.println("Setting price to 150.00");
            stockMarket.setPrice(150.00);
        }
    }
}
