public class ExcelDocumentImpl implements ExcelDocument{
}
