public interface ExcelDocument {
}
