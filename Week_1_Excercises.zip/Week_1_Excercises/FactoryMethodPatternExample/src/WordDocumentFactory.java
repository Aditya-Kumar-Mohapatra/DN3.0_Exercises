public class WordDocumentFactory extends DocumentFactory{
    @Override
    public Document createDocument() {
        return (Document) new WordDocumentFactory();
    }
}
