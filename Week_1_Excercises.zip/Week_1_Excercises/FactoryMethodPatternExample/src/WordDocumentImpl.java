public class WordDocumentImpl implements WordDocument{
}
