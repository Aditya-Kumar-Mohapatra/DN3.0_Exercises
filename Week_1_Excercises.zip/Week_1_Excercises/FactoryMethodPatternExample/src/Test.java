public class Test {
    public static void main(String[] args) {
        DocumentFactory wordFactory = new WordDocumentFactory();
        Document wordDoc = wordFactory.createDocument();
        if (wordDoc instanceof WordDocumentFactory){
            System.out.print("It is word document");
        }
    }
}
