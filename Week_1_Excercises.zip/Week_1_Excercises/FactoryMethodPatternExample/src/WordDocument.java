public interface WordDocument {
}
