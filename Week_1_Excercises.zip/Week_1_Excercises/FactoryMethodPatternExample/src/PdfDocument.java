public interface PdfDocument {
}
