public class PdfDocumentImpl implements PdfDocument{

}
