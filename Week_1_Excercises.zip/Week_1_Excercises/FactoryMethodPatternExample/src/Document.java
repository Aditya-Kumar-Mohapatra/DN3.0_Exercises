public interface Document {
}
