public class RealImage implements Image{
    @Override
    public void display() {
        System.out.print("Loading image from a remote server");
    }
    private String filename;

    public RealImage(String filename) {
        this.filename = filename;
        loadFromDisk();
    }

    private void loadFromDisk() {
        System.out.println("Loading image from disk: " + filename);
    }
}
