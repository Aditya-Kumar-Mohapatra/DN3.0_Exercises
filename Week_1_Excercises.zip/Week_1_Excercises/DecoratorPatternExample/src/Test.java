public class Test {
    public static void main(String[] args) {
        // Testing EmailNotifier
        Notifier emailNotifier = new EmailNotifier();
        emailNotifier.send("Email Message");

        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("SMS Message");

        Notifier emailWithSlack = new SlackNotifierDecorator(emailNotifier);
        emailWithSlack.send("Email with Slack Message");
    }
}
