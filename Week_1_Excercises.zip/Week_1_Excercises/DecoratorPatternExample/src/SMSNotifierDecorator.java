public class SMSNotifierDecorator extends NotifierDecorator {
    public SMSNotifierDecorator(Notifier notifier) {
        super(notifier);
    }

    @Override
    public void send(String message) {
        super.send(message);
        sendToSlack(message);
    }

    private void sendToSlack(String message) {
        System.out.println("Sending SMS notification with message: " + message);
    }
}
