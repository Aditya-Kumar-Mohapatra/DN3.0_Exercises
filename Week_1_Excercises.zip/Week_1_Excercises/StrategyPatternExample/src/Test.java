public class Test {
    public class Main {
        public static void main(String[] args) {
            PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "John Doe", "123", "12/25");
            PaymentContext context = new PaymentContext(creditCardPayment);
            context.executePayment(100.0);

            PaymentStrategy payPalPayment = new PayPalPayment("johndoe@example.com", "securepassword");
            context.setPaymentStrategy(payPalPayment);
            context.executePayment(200.0);
        }
    }
}
