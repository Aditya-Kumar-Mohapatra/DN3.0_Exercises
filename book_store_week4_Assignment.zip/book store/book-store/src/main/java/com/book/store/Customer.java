package com.book.store;

public class Customer {
    private String name;
}
