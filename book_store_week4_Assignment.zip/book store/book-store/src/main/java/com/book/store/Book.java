package com.book.store;

import lombok.Data;

@Data
public class Book {
    private String id;
    private String title;
    private String author;
    private String price;
    private String isbn;
}
