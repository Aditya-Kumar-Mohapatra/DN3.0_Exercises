package com.employee.management;

public interface EmployeeNameProjection {
    String getFirstName();
    String getLastName();
}
