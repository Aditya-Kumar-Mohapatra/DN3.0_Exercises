package com.employee.management;

import jakarta.persistence.NamedQueries;
import jakarta.persistence.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Employee findByEmailAddress(String emailAddress);

    Page<Employee> findByNameameContainingIgnoreCase(String name, Pageable pageable);

    List<EmployeeNameProjection> findAllProjectedBy();

    @Query("SELECT new com.employee.management.EmployeeDTO(e.name, e.email) FROM Employee e")
    List<EmployeeDTO> findAllEmployeeDTOs();
}
