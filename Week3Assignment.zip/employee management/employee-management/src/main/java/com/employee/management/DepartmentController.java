package com.employee.management;

import com.employee.management.Department;
import com.employee.management.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public class DepartmentController {

    @Autowired
    com.employee.management.DepartmentRepository DepartmentRepository;

    @GetMapping("/getDepartment")
    public List<Department> getDepartment(){
        return DepartmentRepository.findAll();
    }

    @PostMapping("/updateDepartment")
    public Department updateDepartment(@RequestBody Department Department){
        return DepartmentRepository.save(Department);
    }

    @PostMapping("/createDepartment")
    public Department createDepartment(@RequestBody Department Department){
        return DepartmentRepository.save(Department);
    }

    @PostMapping("/deleteDepartment")
    public void deleteDepartment(@RequestBody Department Department){
        DepartmentRepository.delete(Department);
    }
}
