package com.employee.management;

public class EmployeeDTO {
    private String fullName;
    private String email;

    public EmployeeDTO(String firstName, String lastName, String email) {
        this.fullName = firstName + " " + lastName;
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }
}
