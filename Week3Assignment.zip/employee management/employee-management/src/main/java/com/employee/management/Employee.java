package com.employee.management;

import jakarta.persistence.*;
import org.hibernate.annotations.BatchSize;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;

@Entity
@Table
@NamedQuery(name = "Employee.findByEmailAddress", query = "select u from Employee u where u.emailAddress = ?1")
@NamedQueries(value = {
        @NamedQuery(name = "Employee.name", query = "select u from Employee u where u.name = ?1")
})
@BatchSize(size = 10)

public class Employee {
    @Id
    @GeneratedValue
    private Long id;

    @CreatedBy
    @LastModifiedBy
    private String name;
    private String email;

    @OneToMany
    private Department department;

    @LastModifiedBy
    private String lastModifiedBy;

    @LastModifiedDate
    private LocalDateTime lastModifiedDate;

}
