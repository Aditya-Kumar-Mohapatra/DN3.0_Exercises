package com.book.store;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
@RestController
@Tag(name = "Books", description = "Operations related to books in the bookstore")

public class BookController {


    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBooksById(@PathVariable("id") String id){
        if (id == null) {
            throw new ResourceNotFoundException("Book not found with id: " + id);
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @GetMapping("/books")
    @Operation(summary = "Get all books", description = "Retrieve a list of all books", responses = {
            @ApiResponse(description = "Successful Operation", responseCode = "200",
                    content = @Content(schema = @Schema(implementation = Book.class))),
            @ApiResponse(description = "No books found", responseCode = "404")
    })
    public ResponseEntity<Book> getBooksById(@RequestParam("title") String title, @RequestParam("author") String author){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Book> createCustomer(@RequestBody Customer customer){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Book> registerCustomer(@RequestBody Customer customer){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @PostMapping("/books")
    public ResponseEntity<Book> postBooks(){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @PutMapping("/books")
    public ResponseEntity<Book> putBooks(){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @DeleteMapping("/books")
    public ResponseEntity<Book> deleteBooks(){
        return new ResponseEntity<>(null, HttpStatus.OK);
    }
}
