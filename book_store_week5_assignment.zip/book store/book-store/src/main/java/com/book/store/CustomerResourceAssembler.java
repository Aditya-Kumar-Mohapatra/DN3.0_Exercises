package com.book.store;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class CustomerResourceAssembler extends RepresentationModelAssemblerSupport<Customer, EntityModel<Customer>> {

    public CustomerResourceAssembler() {
        super(CustomerController.class, EntityModel.class);
    }

    @Override
    public EntityModel<Customer> toModel(Customer customer) {
        EntityModel<Customer> customerModel = EntityModel.of(customer);

        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomer(customer.getId())).withSelfRel();
        Link updateLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).updateCustomer(customer.getId(), customer)).withRel("update");
        Link deleteLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).deleteCustomer(customer.getId())).withRel("delete");

        customerModel.add(selfLink, updateLink, deleteLink);

        return customerModel;
    }
}
