package com.book.store;

import io.micrometer.core.annotation.Counted;
import io.micrometer.core.annotation.Timed;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ActuatorController {
    @GetMapping("/sample")
    @Timed(value = "sample.endpoint.time", description = "Time taken to return sample data")
    @Counted(value = "sample.endpoint.calls", description = "Number of times the sample endpoint is called")
    public String sampleEndpoint() {
        return "Sample Data";
    }
}
