package com.book.store;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.XmlRootElement;
import lombok.Data;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "book")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "id", "title", "author", "price" })
@Data
public class BookXml {
    @XmlElement
    private Long id;

    @XmlElement
    private String title;

    @XmlElement
    private String author;

    @XmlElement
    private double price;
}
