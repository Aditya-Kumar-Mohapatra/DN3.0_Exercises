package com.book.store;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

@Component
public class CustomMetrics {
    public CustomMetrics(MeterRegistry meterRegistry) {
        // Register a custom counter
        meterRegistry.counter("custom_metric_total", "type", "example");
    }
}
