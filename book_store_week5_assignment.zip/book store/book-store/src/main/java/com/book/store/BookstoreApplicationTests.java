package com.book.store;

@SpringBootTest
class BookstoreApplicationTests {

    @Test
    void contextLoads() {
    }
}
