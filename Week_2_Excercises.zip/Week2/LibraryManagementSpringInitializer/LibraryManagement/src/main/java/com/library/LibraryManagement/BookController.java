package com.library.LibraryManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class BookController {

    @Autowired
    BookRepository bookRepository;

    @GetMapping("/create")
    void create() {
        bookRepository.save(new Book());
    }

    @GetMapping("/read")
    Book read() {
        return bookRepository.getReferenceById(1L);
    }

    @GetMapping("/update")
    Book update() {
        return bookRepository.save(new Book());
    }

    @GetMapping("/delete")
    void delete() {
        bookRepository.delete(new Book());
    }
}
