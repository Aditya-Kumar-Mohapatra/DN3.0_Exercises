package com.library.LibraryManagement;

import jakarta.persistence.Entity;

@Entity
public class Book {
    private Long id;
}
