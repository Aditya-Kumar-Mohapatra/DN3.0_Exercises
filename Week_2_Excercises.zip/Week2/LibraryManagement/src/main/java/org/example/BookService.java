package org.example;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void someServiceMethod() {
        // Business logic
        System.out.println("Executing some service logic");
    }
}
