package com.library.LibraryManagement;
public class BookRepository {
    public void someRepositoryMethod() {
        // Data access logic
        System.out.println("Executing some repository logic");
    }

}
