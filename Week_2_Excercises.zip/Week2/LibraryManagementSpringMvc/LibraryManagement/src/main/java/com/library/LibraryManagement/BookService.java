package com.library.LibraryManagement;

import org.springframework.stereotype.Service;

@Service
public class BookService {
    private BookRepository bookRepository;

    // Constructor for constructor injection
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Setter for setter injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void someServiceMethod() {
        bookRepository.someRepositoryMethod();
        System.out.println("Service logic executed with repository's help.");
    }
}
